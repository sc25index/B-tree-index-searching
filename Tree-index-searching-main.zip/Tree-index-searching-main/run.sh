./btree 100000000 /home/z/testdata/performance/newkey_100 /home/z/testdata/performance/newkey_100 5000000 /home/z/testdata/newperf/new-uniform-100-Q5

# ./btree 5000000 /home/z/testdata/performance/newkey_5 /home/z/testdata/performance/newkey_5 1000000000 /home/z/testdata/rangetest/range-uniform-5-Q1000s /home/z/testdata/rangetest/range-uniform-5-Q1000e