# cudaBtreeDynamicMemory

Searching B+Tree Algorithm

Support point query:
- Basic search
- Grouping query search

and range query by:
- Basic search
- 2D-Grouping search
- Z-order search
